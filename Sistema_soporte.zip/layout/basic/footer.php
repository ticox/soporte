<!--     </div>
</div>
<div class="pietop">
www.OrienteX.com.ve

</div>
 <section class="piebody">
        <div class="container">
        <div class="col-xs-12 col-md-4"><span class="glyphicon glyphicon-book" aria-hidden="true"></span> <?php echo APP_SLOGAN ?></div>
        <div class="col-xs-12 col-md-4">Copyright <span class="glyphicon glyphicon-copyright-mark" aria-hidden="true"></span> 2016-2017 </div>
        <div class="col-xs-12 col-md-4"><span class="glyphicon glyphicon-off" aria-hidden="true"></span> web desarrollada por grupo <?php echo APP_COMPANY ?></div>
        <div class="col-xs-12"> <br>
 </div>
        </div>
    </section>

    <div class="piebottom">

        www.OrienteX.com.ve

    </div>


 <!-- Publicos
<script src="<?php echo BASE_URL; ?>public/js/jquery.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/alertify.min.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/config.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine-es.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery-ui.js" type="text/javascript"></script>
<!-- modal plugin
<script src="<?php echo BASE_URL; ?>public/js/modalEffects.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/classie.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/modernizr.custom.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/cssParser.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/clockCountdown.js" type="text/javascript"></script>
<!--
<script src="<?php echo BASE_URL; ?>public/js/css-filters-polyfill.js" type="text/javascript"></script>


<!-- Bootstrap Core JavaScript 
 <script src="<?php echo BASE_URL; ?>public/js/bootstrap.min.js" type="text/javascript"></script>
<!-- Plugin JavaScript 
<!-- Custom Theme JavaScript 
<!--  Js del layout  
 <script src="<?php echo $_layoutParams['ruta_js'];?>header.js" type="text/javascript"></script>
<!--  Js de la vista  
<?php if(isset($_layoutParams['js']) && count($_layoutParams['js'])): ?>
    <?php for($i=0; $i < count($_layoutParams['js']); $i++): ?>
        <script src="<?php echo $_layoutParams['js'][$i] ?>" type="text/javascript"></script>
    <?php endfor; ?>
<?php endif; ?>

</body>

</html>
 -->




 <!--==========================
    New Footer - Nuevo Pie de pagina
  ============================-->
</div>
<script src="<?php echo BASE_URL; ?>public/js/modalEffects.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/classie.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/modernizr.custom.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/cssParser.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/alertify.min.js" type="text/javascript"></script>
  <script src="<?php echo BASE_URL; ?>public/js/jquery.js" type="text/javascript"></script>
  <script src="<?php echo BASE_URL; ?>public/js/config.js" type="text/javascript"></script>
  
  <script src="<?php echo BASE_URL; ?>public/js/bootstrap.min.js"></script>
 <script src="<?php echo BASE_URL; ?>public/js/ripples.min.js"></script>
  <script src="<?php echo BASE_URL; ?>public/js/material.min.js"></script>
  <script src="<?php echo BASE_URL; ?>public/js/jquery-3.1.1.min.js"></script>
<!--   <script src="<?php echo BASE_URL; ?>public/js/sweetalert2.min.js"></script> -->
  <script src="<?php echo BASE_URL; ?>public/js/jquery.mCustomScrollbar.concat.min.js"></script>
  <script src="<?php echo BASE_URL; ?>public/js/main.js"></script>
  <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- JavaScript Libraries
  <script src="<?php echo BASE_URL; ?>lib/jquery/jquery.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/jquery/jquery-migrate.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/easing/easing.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/superfish/hoverIntent.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/superfish/superfish.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/wow/wow.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/waypoints/waypoints.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/counterup/counterup.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/owlcarousel/owl.carousel.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/isotope/isotope.pkgd.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/lightbox/js/lightbox.min.js"></script>
  <script src="<?php echo BASE_URL; ?>lib/touchSwipe/jquery.touchSwipe.min.js"></script>

  <!-- Contact Form JavaScript File
  <script src="<?php echo BASE_URL; ?>public/js/alertify.min.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/config.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery.validationEngine-es.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/modalEffects.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?php echo BASE_URL; ?>public/js/jquery-ui.js" type="text/javascript"></script>

  <!-- Template Main Javascript File -->

<?php if(isset($_layoutParams['js']) && count($_layoutParams['js'])): ?>
    <?php for($i=0; $i < count($_layoutParams['js']); $i++): ?>
        <script src="<?php echo $_layoutParams['js'][$i] ?>" type="text/javascript"></script>
    <?php endfor; ?>
<?php endif; ?>


</body>
</html>