$(document).ready(function(){

$('#agencia').addClass('validate[required]');
$('#preview').addClass('validate[required]');
$('#nro_contacto').addClass('validate[required]');
$('#correo').addClass('validate[required]');
$('#files').addClass('validate[required]');




$('#agregar_agencias').validationEngine();

//$('#form_registro').validationEngine('validate');
				
			

});