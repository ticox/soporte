<?php

define('BASE_URL', 'http://localhost/soporte/');
define('DEFAULT_CONTROLLER', 'login');
define('DEFAULT_LAYOUT', 'basic');
define('APP_NAME', 'Soporte');
define('APP_SLOGAN', 'Soporte');
define('APP_COMPANY', 'COTEDEM');
define('APP_TLF', '');
define('APP_EMAIL', '');
define('SESSION_TIME', 1000000);
define('HASH_KEY', '4f6a6d832be79');
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'soporte');
define('DB_CHAR', 'utf8');
?>